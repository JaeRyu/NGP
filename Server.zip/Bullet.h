#pragma once
#include "Player.h"
class CBullet :
	public CPlayer
{
private:
	/*�����Ѿ� : 0, ���Ѿ� : 1 */
	int type;
	float x, y;
private:
	void Initialize(void);
	void Release(void);
	
public:
	void SetType(int tType);
	int Update(void);
	void SetInfo(INFO tInfo)
	{
		x = tInfo.posX;
		y = tInfo.posY;
	}
	INFO GetInfo(void)
	{
		INFO tInfo;
		tInfo.posX = x;
		tInfo.posY = y;
		tInfo.state = m_tInfo.state;
		return tInfo;
	}
	IBULLET GetBulletInfo(void);
	CBullet();
	~CBullet();
};

